from flask import Flask, request, render_template
import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler

# Initialize Flask app
app = Flask(__name__)

# Load scaler and model
try:
    scaler = pickle.load(open('scaler.pkl', 'rb'))
    model = pickle.load(open('lr_model.pkl', 'rb'))
    print("Scaler and model loaded successfully")
except FileNotFoundError as e:
    print(f"Error: Could not find file - {str(e)}")
    exit(1)
except Exception as e:
    print(f"Error loading scaler/model: {str(e)}")
    exit(1)

@app.route('/', methods=['GET', 'POST'])
def home():
    """
    Handle both GET and POST requests for the home page.
    - GET: Render the form with no prediction.
    - POST: Process form data and return a prediction.
    """
    prediction = -1  # Default value for no prediction

    if request.method == 'POST':
        try:
            # Extract and convert form data
            pregs = int(request.form.get('pregs', 0))
            gluc = int(request.form.get('gluc', 0))
            bp = int(request.form.get('bp', 0))
            skin = int(request.form.get('skin', 0))
            insulin = float(request.form.get('insulin', 0.0))
            bmi = float(request.form.get('bmi', 0.0))
            func = float(request.form.get('func', 0.0))
            age = int(request.form.get('age', 0))

            # Prepare input features for prediction
            input_features = [[pregs, gluc, bp, skin, insulin, bmi, func, age]]
            scaled_features = scaler.transform(input_features)
            prediction = model.predict(scaled_features)[0]  # Get the first prediction

        except ValueError as ve:
            print(f"Invalid input: {str(ve)}")
            prediction = "Error: Invalid input values"
        except Exception as e:
            print(f"Prediction error: {str(e)}")
            prediction = "Error: Prediction failed"

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)