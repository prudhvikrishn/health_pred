import pickle
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split

# Load sample data (diabetes dataset for demonstration)
data = load_diabetes()
X = data.data[:, :8]  # Use first 8 features to match your Flask app
y = (data.target > data.target.mean()).astype(int)  # Binarize target for logistic regression

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the logistic regression model
model = LogisticRegression(max_iter=1000)  # Increase max_iter if convergence issues occur
model.fit(X_train, y_train)

# Evaluate the model (optional)
accuracy = model.score(X_test, y_test)
print(f"Model accuracy: {accuracy:.2f}")

# Save the model to a file
with open('lr_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("Model saved as 'lr_model.pkl'")