import pickle
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_diabetes  # Using a sample dataset for demonstration

# Load sample data (you can replace this with your own dataset)
data = load_diabetes()
X = data.data  # Features (10 features, we'll adjust to match 8 later)
# Pregnancies, Glucose, Blood Pressure, Skin Thickness, Insulin, BMI, Diabetes Pedigree, Age
# Here, we'll just use the first 8 columns of the diabetes dataset for simplicity
X = X[:, :8]  # Limiting to 8 features

# Initialize and fit the scaler
scaler = StandardScaler()
scaler.fit(X)

# Save the scaler to a file
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

print("Scaler saved as 'scaler.pkl'")
#0 → No Risk of Diabetes
#1 → At Risk of Diabetes